using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace ProvidenceMod.Developer //this is the pathway that the code digs through to find the item.
{
  public class GreatSword : ModItem //this contains methods and labels "things"
  {
	public override void SetStaticDefaults() //this thing is called a method, everything inside it are instructions for the methed to follow.
	{
	  DisplayName.SetDefault("Great Sword"); //these are the instructions.
	  Tooltip.SetDefault("Look, it's a big sword, ok? Hit things hard with it.");
	}
	public override void SetDefaults()
	{
    item.melee = true;  //I wonder what this does
		item.useTime = 500; 
		item.useAnimation = 10;
		item.useStyle = ItemUseStyleID.SwingThrow;
		item.damage = 242;
		item.useTurn = true;
		item.UseSound = SoundID.Item1;
		item.width = 100;
		item.height = 100;
		item.rare = (int)ProvidenceRarity.Developer;
		item.knockBack = 200;
	}
  }
}