using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace ProvidenceMod.Developer //this is the pathway that the code digs through to find the item.
{
  public class GretSord : ModItem //this contains methods and labels "things"
  {
	public override void SetStaticDefaults() //this thing is called a method, everything inside it are instructions for the methed to follow.
	{
	  DisplayName.SetDefault("Gret Sord"); //these are the instructions.
	  Tooltip.SetDefault("Unnga Grug use Gret Sord. Grug hit hard very boss with Sord.");
	}
	public override void SetDefaults()
	{
    item.melee = true;  //I wonder what this does
		item.useTime = 50; 
		item.useAnimation = 10;
		item.useStyle = ItemUseStyleID.SwingThrow;
		item.damage = 100000000;
		item.useTurn = true;
		item.UseSound = SoundID.Item1;
		item.width = 800;
		item.height = 800;
		item.rare = (int)ProvidenceRarity.Developer;
	}
  }
}