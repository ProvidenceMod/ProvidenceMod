using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace ProvidenceMod.Developer
{
	public class LargeGear : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Large Gear");
			Tooltip.SetDefault("A large Gear found within the Clockworks. It would probably be quite effective if launched at something.");
		}
		public override void SetDefaults()
		{
			item.height = 22;
			item.width = 22;
			item.value = Item.buyPrice(0, 0, 7, 53);
      item.shootSpeed = 4f;
      item.damage = 120;
      item.ranged = true;
      item.maxStack = 999;
      item.consumable = true;
      item.knockBack = 50f;
      item.rare = (int)ProvidenceRarity.Celestial;
      item.shoot = ProjectileType<LargeGearProjectile>();
      item.ammo = AmmoID.Bullet;
		}
	}
}