using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ModLoader;
using static ProvidenceMod.ProvidenceUtils;
using Terraria.ID;
namespace ProvidenceMod.Developer
{
	public class LargeGearProjectile : ModProjectile
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Large Gear");
		}
		public override void SetDefaults()
		{
			projectile.width = 38;
			projectile.height = 38;
			projectile.penetrate = -1;
			projectile.friendly = true;
			projectile.scale = 1f;
			projectile.hide = false;
			projectile.aiStyle = 14;
			projectile.ranged = true;
			projectile.timeLeft = 30f.InTicks();
			projectile.damage = 70;
			projectile.knockBack = 40;


		}
		public override void AI()//this is a method, they have to have () <-- those things
		{
			projectile.rotation += projectile.velocity.X*0.05f ;
    }
  }
}