using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;
using ProvidenceMod.Projectiles.Ranged;
namespace ProvidenceMod.Developer
{
	public class RoomClearer : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("The Room Clearer");
			Tooltip.SetDefault("A Massicre machine!");
		}
		public override void SetDefaults()
		{
			item.damage = 20000;
			item.width = 100;
			item.height = 46;
			item.value = Item.buyPrice(0, 10, 0, 0);
			item.rare = (int)ProvidenceRarity.Purple;
			item.useTime = 5;
			item.useAnimation = 26;
			item.useTurn = false;
			item.useStyle = ItemUseStyleID.HoldingOut;
			item.scale = 1.0f;
			item.ranged = true;
			item.noMelee = true;
			item.autoReuse = true;
			item.useAmmo = AmmoID.Bullet;
			item.shoot = ProjectileType<AntimatterBullet>();
			item.shootSpeed = 20f;
			item.UseSound = SoundID.DD2_PhantomPhoenixShot;
		}

		public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
		{
			for (int i = 0; i < 50; i++){
        Vector2 pSpeed = new Vector2(speedX, speedY).RotatedByRandom(15f.InRadians());
        int projectile = Projectile.NewProjectile(player.position, pSpeed, ProjectileType<AntimatterBullet>(), damage, knockBack, player.whoAmI );
        Projectile Projectile2 = Main.projectile[projectile];
        Projectile2.penetrate = 10;
      }
			return false;
		}
	}
}