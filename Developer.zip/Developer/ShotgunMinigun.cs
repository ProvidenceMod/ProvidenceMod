using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static ProvidenceMod.ProvidenceUtils;
namespace ProvidenceMod.Developer
{
	public class ShotgunMinigun : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Shotgun Minigun");
			Tooltip.SetDefault("Ok look, Basically it's a shotgun, that shoots really really fast. Have fun.");
		}
		public override void SetDefaults()
		{
			item.damage = 150;
			item.width = 100;
			item.height = 46;
			item.value = Item.buyPrice(0, 10, 0, 0);
			item.rare = (int)ProvidenceRarity.Purple;
			item.useTime = 10;
			item.useAnimation = 26;
			item.useTurn = false;
			item.useStyle = ItemUseStyleID.HoldingOut;
			item.scale = 1.0f;
			item.ranged = true;
			item.noMelee = true;
			item.autoReuse = true;
			item.useAmmo = AmmoID.Bullet;
			item.shoot = ProjectileID.Bullet;
			item.shootSpeed = 20f;
			item.UseSound = SoundID.DD2_PhantomPhoenixShot;
      //target.immune[projectile.owner] = 1;
		}

		public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
		{
			for (int i = 0; i < 7; i++){
        Vector2 pSpeed = new Vector2(speedX, speedY).RotatedByRandom(15f.InRadians());
        int projectile = Projectile.NewProjectile(player.position, pSpeed, type, damage, knockBack, player.whoAmI );
        Projectile Projectile2 = Main.projectile[projectile];
        Projectile2.penetrate = 10;
      }
			return false;
		}
	}
}